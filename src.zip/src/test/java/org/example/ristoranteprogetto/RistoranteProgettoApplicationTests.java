package org.example.ristoranteprogetto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RistoranteProgettoApplicationTests {

    @Test
    void contextLoads() {
    }

}
