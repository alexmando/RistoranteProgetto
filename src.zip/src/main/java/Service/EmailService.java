package Service;

public class EmailService {
}
