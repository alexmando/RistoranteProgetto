package Model.Entity;

public enum Role {
    USER,
    ADMIN
}
