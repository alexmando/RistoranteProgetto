package Model.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

// ogni prenotazione è legata ad un utente e ad uno specifico tavolo,
// mentre un tavolo e un utente possono avere molteplici prenotazioni.

@Data
@Entity
@jakarta.persistence.Table(name = "prenotazioni")
public class ReservationEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate data;

    private LocalTime orario;

    private int numeroPersone;

    @Getter
    @Setter
    private String status; // es. "IN_ATTESA", "CONFERMATA", "RIFIUTATA"

    private Long userId;
    private Long tableId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private UserEntity user;

    @ManyToOne
    @JoinColumn(name = "table_id", nullable = false)
    private TableEntity table;

    public void setTime(LocalTime time) {
        this.orario = time;
    }

    public LocalTime getTime() {
        return this.orario;
    }

    public void setPeople(int people) {
        this.numeroPersone = people;
    }

    public int getPeople() {
        return this.numeroPersone;
    }

}